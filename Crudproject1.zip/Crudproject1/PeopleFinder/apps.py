from django.apps import AppConfig


class PeoplefinderConfig(AppConfig):
    name = 'PeopleFinder'
