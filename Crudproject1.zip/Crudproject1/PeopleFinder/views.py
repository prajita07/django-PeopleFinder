from django.shortcuts import render, HttpResponseRedirect
from .forms import FindPeople
from .models import Add


# Create your views here.
def add_show(request) :
    if request.method == 'POST':
     form= FindPeople(request.POST, request.FILES)
     if form.is_valid():
        nm= form.cleaned_data['name']
        im= form.cleaned_data['image']
        cn= form.cleaned_data['country']
        ag= form.cleaned_data['age']
        reg=  Add(name=nm, image=im, country=cn, age=ag)
        reg.save()
        form= FindPeople()
    else:
     form= FindPeople()
    
        
    fnd= Add.objects.all()

    return render (request, 'PeopleFinder/addandshow.html', {'form':form, 'fnd': fnd })

#This function will update
def update_data(request, id) :
  if request.method == 'POST' :
    pi = Add.objects.get(pk=id)
    form = FindPeople(request.POST,request.FILES,  instance=pi)
    if form.is_valid():
      form.save()
      
  else:
    pi = Add.objects.get(pk=id)
    form = FindPeople(instance=pi)
    
  return render(request, 'PeopleFinder/update.html', {'form' : form})



  #This function will delete 
def delete_data(request, id): 
    if request.method == 'POST' :
      pi = Add.objects.get(pk=id)
      pi.delete()
      return HttpResponseRedirect('/')

def search_people(request):
   if request.method == 'POST':
     peoples = Add.objects.filter(name__icontains=request.POST.get('search'))
     context = {
       'addandshow': peoples
       }
     return render(request, 'PeopleFinder/addandshow.html', context)
   return redirect('addandshow')