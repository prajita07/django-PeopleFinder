from django.db import models

# Create your models here.
class Add(models.Model) :
    image= models.ImageField(upload_to='pictures/%y/%m/%D/', null=True, blank= True)
    name= models.CharField(max_length=70)
    country= models.CharField(max_length=100)
    age= models.IntegerField(null=False)