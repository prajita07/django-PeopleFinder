from django.core import validators
from django import forms
from .models import Add


class FindPeople (forms.ModelForm):
    class Meta:
        model = Add
        fields = [ 'image', 'name', 'country', 'age']
        widgets = {
            'image' : forms.FileInput(attrs={'class': 'form-control'}),
            'name' : forms.TextInput(attrs={'class': 'form-control'}),
            'country' : forms.TextInput(attrs={'class': 'form-control'}),
            'age' : forms.NumberInput(attrs={'class': 'form-control'}),
        }
